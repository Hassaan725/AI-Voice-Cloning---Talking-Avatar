from gtts import gTTS
import os

# Text you want to convert to speech
text = "Evolvian Softwares is redefining technology with AI-driven solutions that transform bold ideas into impactful realities."

# Language (English = 'en', Urdu = 'ur')
language = 'ur'

# Create gTTS object
tts = gTTS(text=text, lang=language, slow=False)

# Save audio file
output_file = "output_audio.mp3"
tts.save(output_file)

# Print where the file is saved
print("Audio file generated at:", os.path.abspath(output_file))
