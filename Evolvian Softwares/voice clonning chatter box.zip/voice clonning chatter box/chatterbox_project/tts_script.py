import torchaudio as ta
from chatterbox.tts import ChatterboxTTS
import torch

# Model load karo
model = ChatterboxTTS.from_pretrained(device="cpu")  # Agar GPU hai to "cuda" daalo

# Text jo bolna hai
text = "Hi there, this is a quick test of my cloned voice. Pretty close to the real thing!"

# Apni WAV file ka path (Desktop pe hai)
audio_prompt_path = r"C:\Users\DELL\Desktop\harvard.wav"

# Versions check (optional)
print("Torch version:", torch.__version__)
print("Torchaudio version:", ta.__version__)

# Clone voice
wav = model.generate(text, audio_prompt_path=audio_prompt_path)

# Save output
output_file = "cloned_output.wav"
ta.save(output_file, wav, model.sr)
print(f"Saved cloned voice: {output_file}")
