# chatterbox_run.py
"""
Simple wrapper to load Chatterbox-TTS and synthesize a short clip.
Works on CPU or CUDA (if available and properly installed).
"""

import os
import sys
import numpy as np

try:
    import torch
    import torchaudio as ta
    from chatterbox.tts import ChatterboxTTS
except Exception as e:
    print("Missing dependency. Run: pip install chatterbox-tts torchaudio torch")
    print("Error:", e)
    sys.exit(1)


def ensure_wave_tensor(wav):
    # Accepts numpy arrays or torch tensors and returns tensor shape (channels, samples), dtype=float32
    if isinstance(wav, np.ndarray):
        # wav shape might be (samples,) or (samples, channels)
        if wav.ndim == 1:
            wav_t = torch.from_numpy(wav).unsqueeze(0)
        elif wav.ndim == 2:
            # convert (samples, channels) -> (channels, samples)
            wav_t = torch.from_numpy(wav).T
        else:
            raise ValueError("Unexpected numpy wav shape: " + str(wav.shape))
    elif isinstance(wav, torch.Tensor):
        if wav.dim() == 1:
            wav_t = wav.unsqueeze(0)
        elif wav.dim() == 2 and wav.shape[0] > wav.shape[1]:
            # likely (channels, samples) already
            wav_t = wav
        elif wav.dim() == 2:
            # could be (samples, channels) -> transpose
            wav_t = wav.T
        else:
            raise ValueError("Unexpected torch wav dims: " + str(wav.shape))
    else:
        raise ValueError("wav must be numpy array or torch.Tensor, got " + str(type(wav)))
    return wav_t.float()


def main():
    print("Python:", sys.version.splitlines()[0])
    print("torch:", torch.__version__)
    print("torchaudio:", ta.__version__)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Using device:", device)

    # Load model (first run will download model files -> needs internet + disk)
    try:
        model = ChatterboxTTS.from_pretrained(device=device)
    except Exception as e:
        print("Failed to load ChatterboxTTS model. Error:", e)
        print("Make sure 'chatterbox-tts' is installed and you have internet for the first download.")
        sys.exit(1)

    print("Model loaded. sample rate:", model.sr)

    # EDIT THESE
    TEXT_TO_SYNTHESIZE = "Hi there, this is a quick test of my cloned voice. Pretty close to the real thing!"
    AUDIO_PROMPT_PATH = None  # or "path/to/your_reference.wav"  (use wav, ~10s+, clean)

    # generate
    try:
        if AUDIO_PROMPT_PATH:
            if not os.path.isfile(AUDIO_PROMPT_PATH):
                raise FileNotFoundError(f"Audio prompt not found: {AUDIO_PROMPT_PATH}")
            wav = model.generate(TEXT_TO_SYNTHESIZE, audio_prompt_path=AUDIO_PROMPT_PATH)
        else:
            wav = model.generate(TEXT_TO_SYNTHESIZE)

        # convert to proper torch tensor shape and save
        wav_t = ensure_wave_tensor(wav)
        out_fname = "cloned_output.wav"
        ta.save(out_fname, wav_t, model.sr)
        print("Saved:", os.path.abspath(out_fname))
    except Exception as e:
        print("Generation failed:", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
