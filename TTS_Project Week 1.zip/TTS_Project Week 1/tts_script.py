from gtts import gTTS
import os


text = """
Evolvian Softwares is redefining technology with AI-driven solutions that transform bold ideas into impactful realities.
"""

language = 'ur'


tts = gTTS(text=text, lang=language, slow=False)


output_file = "output_audio.mp3"
tts.save(output_file)


print(f"Audio file generated: {os.path.abspath(output_file)}")